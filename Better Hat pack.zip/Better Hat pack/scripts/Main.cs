﻿using UnityEngine;
using System;
using System.Collections.Generic;

public class DynamicCode
{
    // In front defines if your hat will overlay the player or be behind him
    // Product id is hat name (unused for now but will 100% be used later)
    // Main image is the path for the sprite

    // Change this to add hats

    private List<HatData> hatList = new List<HatData>
    {
        new HatData { InFront = true, Size = 0.2f , ProductId = "Nerd hat", MainImagePath = "resources/images/MahadS hat.png" },
        new HatData { InFront = false, Size = 0.3f , ProductId = "LimeHat", MainImagePath = "resources/images/Lime hat.png" },
        new HatData { InFront = true, Size = 0.2f , ProductId = "Nerd", MainImagePath = "resources/images/Nerd.png" },
        new HatData { InFront = true, Size = 0.2f , ProductId = "Olive hat", MainImagePath = "resources/images/Olive.png" },
        new HatData { InFront = true, Size = 0.2f , ProductId = "CuteCat hat", MainImagePath = "resources/images/cutecat.png" },
       new HatData { InFront = true, Size = 0.4f , ProductId = "2024 hat", MainImagePath = "resources/images/2024.png" },
       new HatData { InFront = true, Size = 0.2f , ProductId = "CuteCat hat", MainImagePath = "resources/images/cutecat.png" },
       new HatData { InFront = false, Size = 0.3f , ProductId = "2024 hat", MainImagePath = "resources/images/2024.png" },
        new HatData { InFront = true, Size = 1.2f , ProductId = "IceCream", MainImagePath = "resources/images/icecream.png" },
        new HatData { InFront = true, Size = 0.3f , ProductId = "Gift", MainImagePath = "resources/images/gift.png" },
        new HatData { InFront = true, Size = 0.5f , ProductId = "scream", MainImagePath = "resources/images/scream.png" },
        new HatData { InFront = false, Size = 0.2f , ProductId = "Cheese Hat", MainImagePath = "resources/images/cheesehat.png" },
};


    //--BELOW ONLY FOR ADVANCED USERS--ONLY CHANGE THIS IF YOU KNOW WHAT YOU'RE DOING.--//
    public class HatData
    {
        public bool InFront { get; set; }
        public float Size { get; set; }
        public string ProductId { get; set; }
        public string MainImagePath { get; set; }
    }
    public void Execute()
    {
        foreach (var hatData in hatList)
        {
            // Load the sprite from the image path
            Sprite mainImage = ImageUtils.LoadNewSprite(ModsManager.Instance.GetPathFromMod(Paths.folderName, hatData.MainImagePath), 300f / hatData.Size, SpriteMeshType.FullRect);

            // Add the hat with the loaded sprite
            AddHat(hatData.ProductId, mainImage, hatData.InFront);
        }
    }

    public static void AddHat(string prodId, Sprite mainImage, bool inFront)
    {
        HatBehaviour hat = new HatBehaviour
        {
            InFront = inFront,
            MainImage = mainImage,
            FloorImage = mainImage,
            ProductId = prodId,
            StoreName = "",
        };
        HatManager.Instance.AllHats.Add(hat);
    }
}